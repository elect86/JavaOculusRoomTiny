/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oculusRoomTiny.rendering;

/**
 *
 * @author gbarbieri
 */
public class TextureFormat {
    
    public final static int RGBA = 0x100;
    public final static int SRGB = 0x80000;
    public final static int TypeMask = 0xff00;
    public final static int Depth = 0x8000;
}
